<?php

namespace App\Controller;

use App\Entity\Menu;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MenuController extends AbstractController
{
    /**
     * @Route("/menu", name="menu")
     */
    public function index(): Response
    {
        return $this->render('menu/index.html.twig', [
            'controller_name' => 'MenuController',
        ]);
    }

    /**
     * @Route("/ges/menu/create", name="menu_create", methods={"GET", "POST"})
     */
    public function create(Request $request, EntityManagerInterface $em): Response
    {

        $form = $this->createFormBuilder()
            -> add('nom')
            ->add('image')
            ->add('prix',MoneyType::class)
            ->add('submit', SubmitType::class, ['label'=>'créer boisson'])
            ->getForm()
        ;

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            // pour obtenir toutes les valeurs qu'on a mis dans le formulaire
            $data = $form->getData();
            $menu = new Menu;
            $menu->setNom($data['nom']);
            $menu->setimage($data['image']);
            // pour récuperer une valeur particulière par exemple le nom qu'on mis dans le formulaire
            $nom = $form->get('prix')->getData();
            $menu->setPrix((int)($data['prix']));
            $em->persist($menu);
            $em->flush();
            return $this->redirectToRoute('home');
        }

        return $this->render('menu/create.html.twig',[
          'monFormulaire'=>$form ->createView() 
        ]);
    }
    
}