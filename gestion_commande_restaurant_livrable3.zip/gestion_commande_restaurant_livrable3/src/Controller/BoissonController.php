<?php

namespace App\Controller;

use App\Entity\Boisson;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

class BoissonController extends AbstractController
{
    /**
     * @Route("/boisson", name="boisson")
     */
    public function index(): Response
    {
        return $this->render('boisson/index.html.twig', [
            'controller_name' => 'BoissonController',
        ]);
    }

    /**
     * @Route("/ges/boisson/create", name="boisson_create", methods={"GET", "POST"})
     */
    public function create(Request $request, EntityManagerInterface $em): Response
    {

        $form = $this->createFormBuilder()
            -> add('nom')
            ->add('image')
            ->add('prix',MoneyType::class)
            ->add('submit', SubmitType::class, ['label'=>'créer boisson'])
            ->getForm()
        ;

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            // pour obtenir toutes les valeurs qu'on a mis dans le formulaire
            $data = $form->getData();
           
            $boisson = new Boisson;
            $boisson->setNom($data['nom']);
            $boisson->setimage($data['image']);
            // pour récuperer une valeur particulière par exemple le nom qu'on mis dans le formulaire
            $nom = $form->get('prix')->getData();
            $boisson->setPrix((int)($data['prix']));
            $em->persist($boisson);
            $em->flush();
            return $this->redirectToRoute('home');
        }

        return $this->render('boisson/create.html.twig',[
          'monFormulaire'=>$form ->createView() 
        ]);
    }
}