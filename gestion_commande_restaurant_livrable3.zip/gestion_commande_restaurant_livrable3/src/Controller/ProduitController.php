<?php

namespace App\Controller;

use App\Entity\Produit;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ProduitController extends AbstractController
{
    /**
     * @Route("/produit", name="produit")
     */
    public function index(): Response
    {
        return $this->render('produit/index.html.twig', [
            'controller_name' => 'ProduitController',
        ]);
    }

    

    /**
     * @Route("/ges/produit/create", name="produit_create", methods=["GET", "POST"])
     */
    public function createProduit(Request $request, EntityManagerInterface $em): Response
    {
       
        if($request->isMethod("POST")){
            
        
        //dd($request);
           $data =  $request->request->all();
           $produit = new Produit;
           $produit->setNom($data["nom"]);
           $produit->setImage($data["image"]);
           $produit->setPrix($request->request->getInt("prix"));
           //$produit->setPrix($data["prix"]);
           $type = $data["nom_prod"];
           $em->persist($produit);
           $em->flush();

           return $this->redirectToRoute('home');
            }
           
        
        
        return $this->render('produit/add.html.twig');
    }
    
}