<?php

namespace App\Controller;

use App\Entity\Burger;
use App\Repository\BurgerRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class BurgerController extends AbstractController
{
    /**
     * @Route("/burger", name="burger")
     */
    public function index(): Response
    {
        return $this->render('burger/index.html.twig');
    }

    /**
     * @Route("/ges/burger/create", name="burger_create", methods={"GET", "POST"})
     */
    public function create(Request $request, EntityManagerInterface $em): Response
    {

        $form = $this->createFormBuilder()
            -> add('nom')
            ->add('image')
            ->add('prix',MoneyType::class)
            ->add('submit', SubmitType::class, ['label'=>'créer boisson'])
            ->getForm()
        ;

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            // pour obtenir toutes les valeurs qu'on a mis dans le formulaire
            $data = $form->getData();
           
            $burger = new Burger;
            $burger->setNom($data['nom']);
            $burger->setimage($data['image']);
            // pour récuperer une valeur particulière par exemple le nom qu'on mis dans le formulaire
            $nom = $form->get('prix')->getData();
            $burger->setPrix((int)($data['prix']));
            $em->persist($burger);
            $em->flush();
            return $this->redirectToRoute('home');
        }

        return $this->render('burger/create.html.twig',[
          'monFormulaire'=>$form ->createView() 
        ]);
    }

    /**
     * @Route("/ges/burger/list", name="burger_show", methods={"GET"})
     */
    public function show(BurgerRepository $repo): Response
    {
        $burgers = $repo->findAll(); 
        return $this->render('burger/show.html.twig',[
            'burgers' => $burgers
        ]);
    }
    
}