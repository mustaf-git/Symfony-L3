<?php

namespace App\DataFixtures;

use App\Entity\Paiement;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;

class PaiementFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager): void
    {

        
        for ($i = 1; $i <=3; $i++) {

            

            $paiement = new Paiement();
            $commande = $this->getReference("Commande".$i);
            $paiement->setDateAt($i."/12/2021");
            $paiement->setMontant(10000);
            $paiement->setCommande($commande); 
            $manager->persist($paiement);
            $this->addReference("Paiement".$i, $paiement);
            
            
        }
        
        $manager->flush();
    }
    public function getDependencies()
    {
    return [
            
            CommandeFixtures::class,
        ];
    }

    
}