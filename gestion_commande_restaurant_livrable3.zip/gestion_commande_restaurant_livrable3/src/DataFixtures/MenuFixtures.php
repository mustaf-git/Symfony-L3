<?php

namespace App\DataFixtures;

use App\Entity\Menu;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class MenuFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        
        $prixBurgers = [1500, 2000, 2500];
        $prixFrites = [500, 1000, 1500];
        $prixBoissons = [700, 1000, 2000];
        
        for ($i = 1; $i <=5; $i++) {
            
            $indice = rand(0,2);
            $produit = new Menu();
            $produit->setNom("menu".$i);
            $produit->setImage("image".$i);
            $prixMenu = $prixBurgers[$indice]+$prixFrites[$indice]+$prixBoissons[$indice];
            $produit->setPrix($prixMenu);
            $produit->setBurger($this->getReference("Burger".$i));
            $produit->addBoisson($this->getReference("Boisson".$i));
            $produit->addFrite($this->getReference("Frite".$i));
            $manager->persist($produit);
            $this->addReference("Menu".$i, $produit);
        }
        
        $manager->flush();

    }
}