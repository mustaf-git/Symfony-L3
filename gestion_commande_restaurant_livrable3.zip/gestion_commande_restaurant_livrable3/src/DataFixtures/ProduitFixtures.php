<?php

namespace App\DataFixtures;

use App\Entity\Produit;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class ProduitFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        
        $prix=[1000, 2000, 3000];
        
        for ($i = 1; $i <=5; $i++) {
            $indice = rand(0,2);
            $produit = new Produit();
            $produit->setNom("produit".$i);
            $produit->setImage("image".$i);
            $produit->setPrix($prix[$indice]);
            $manager->persist($produit);
            $this->addReference("Produit".$i, $produit);
        }

        $manager->flush();

    }
}