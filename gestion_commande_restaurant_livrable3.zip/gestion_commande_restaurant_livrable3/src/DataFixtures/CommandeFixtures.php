<?php

namespace App\DataFixtures;

use App\Entity\Client;
use App\Entity\Commande;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;

class CommandeFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager): void
    {
        $etat=["en attente", "terminée", "payé"];
        $prod=["Burger", "Menu", "Frite", "Boisson"];
        
        for ($i = 1; $i <=5; $i++) {

            
            $indiceEtat = rand(0,2);
            $indiceProd= rand(0,3);
            $commande = new Commande();
            $commande->setLibelle("commande".$i);
            $commande->setDateAt($i."/12/2021");
            $commande->setEtat($etat[$indiceEtat]);
            $commande->setClient($this->getReference("Client".$i));
            $commande->addProduit($this->getReference($prod[$indiceProd].$i));
            $manager->persist($commande);
            $this->addReference("Commande".$i, $commande);
            
        }
        $manager->flush();
    }

    public function getDependencies()
    {
    return [
            
            FriteFixtures::class,
            MenuFixtures::class,
           
    ];
    }

}