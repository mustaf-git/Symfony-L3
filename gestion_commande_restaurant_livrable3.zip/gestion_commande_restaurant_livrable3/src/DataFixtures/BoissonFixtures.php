<?php

namespace App\DataFixtures;

use App\Entity\Boisson;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class BoissonFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        
        $prix=[300, 700, 1000];
        
        for ($i = 1; $i <=5; $i++) {
            $indice = rand(0,2);
            $produit = new Boisson();
            $produit->setNom("boisson".$i);
            $produit->setImage("image".$i);
            $produit->setPrix($prix[$indice]);
            $manager->persist($produit);
            $this->addReference("Boisson".$i, $produit);
        }

        $manager->flush();

    }
}