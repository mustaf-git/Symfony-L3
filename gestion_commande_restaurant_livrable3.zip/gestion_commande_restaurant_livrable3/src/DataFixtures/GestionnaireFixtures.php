<?php

namespace App\DataFixtures;

use App\Entity\Gestionnaire;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class GestionnaireFixtures extends Fixture
{
    private $encoder;
    public function __construct(UserPasswordHasherInterface $encoder){
        $this->encoder=$encoder;
    }
    
    public function load(ObjectManager $manager): void
    {
        
        $plainPassword = 'passer@123';
        for ($i = 1; $i <=2; $i++) {
            $user = new Gestionnaire();
            $user->setEmail("gestionnaire".$i."@gmail.com");
            $encoded = $this->encoder->hashPassword($user, $plainPassword);
            $user->setPassword($encoded);
            $user->setRoles(["ROLE_GESTIONNAIRE"]);
            $manager->persist($user);
            $this->addReference("Gestionnaire".$i, $user);
        }
        
        $manager->flush();

    }
}