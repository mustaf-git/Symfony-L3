<?php

namespace App\DataFixtures;

use App\Entity\Frite;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class FriteFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        
        $prix=[500, 1000, 1500];
        
        for ($i = 1; $i <=5; $i++) {
            $indice = rand(0,2);
            $produit = new Frite();
            $produit->setNom("frite".$i);
            $produit->setImage("image".$i);
            $produit->setPrix($prix[$indice]);
            $manager->persist($produit);
            $this->addReference("Frite".$i, $produit);
        }
        
        $manager->flush();

    }
}