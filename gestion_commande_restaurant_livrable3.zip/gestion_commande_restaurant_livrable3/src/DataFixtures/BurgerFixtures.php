<?php

namespace App\DataFixtures;

use App\Entity\Burger;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Bundle\FixturesBundle\Fixture;

class BurgerFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        
        $prix=[1500, 2000, 2500];
        
        for ($i = 1; $i <=5; $i++) {
            $indice = rand(0,2);
            $produit = new Burger();
            $produit->setNom("burger".$i);
            $produit->setImage("image".$i);
            $produit->setPrix($prix[$indice]);
            $manager->persist($produit);
            $this->addReference("Burger".$i, $produit);
        }
        
        $manager->flush();

    }
}