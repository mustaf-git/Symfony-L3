<?php

namespace App\DataFixtures;

use App\Entity\Client;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class ClientFixtures extends Fixture
{
    
    private $encoder;
        public function __construct(UserPasswordHasherInterface $encoder){
        $this->encoder=$encoder;
    }

    public function load(ObjectManager $manager): void
    {
        
        $plainPassword = 'passer@123';
        for ($i = 1; $i <=10; $i++) {
        $user = new Client();
        $user->setNom('Nom '.$i);
        $user->setPrenom('prenom '.$i);
        $user->setTelephone('77 123 45 6'.$i);
        $user->setEmail('client'.$i."@gmail.com");
        $encoded = $this->encoder->hashPassword($user, $plainPassword);
        $user->setPassword($encoded);
        $user->setRoles(["ROLE_CLIENT"]);
        $manager->persist($user);
        $this->addReference("Client".$i, $user);
        }
        $manager->flush();
    }
}